# Tunora backend setup (Supabase)

This adds: daily auto-update of new songs, plus Daily Mix, Discover Weekly,
Repeat Rewind and Fresh Releases playlists that follow what you listen to.

## 1. Create the project
1. Go to https://supabase.com and create a free project.
2. **Authentication -> Sign In / Providers -> Allow anonymous sign-ins: ON.**
   (Listeners get a private id automatically, so no login screen is needed.)

## 2. Create the tables and playlist logic
SQL Editor -> New query -> paste all of `supabase/schema.sql` -> Run.

## 3. Deploy the sync function
Install the Supabase CLI (https://supabase.com/docs/guides/cli), then from the
project root:

```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase secrets set SYNC_SECRET=pick-a-long-random-text JAMENDO_CLIENT_ID=your_jamendo_id
supabase functions deploy sync-music --no-verify-jwt
```

## 4. Fill the catalog once (manual test)
```bash
curl -X POST https://YOUR_PROJECT_REF.supabase.co/functions/v1/sync-music \
  -H "x-sync-secret: pick-a-long-random-text"
```
You should get `{"ok":true,"fetched":...,"newSongs":...,"totalSongs":...}`.
Check Table Editor -> `tracks` to see the songs.

## 5. Schedule it daily
Edit the two placeholders in `supabase/cron.sql`, then run it in the SQL Editor.
New songs are then added every day at 03:00 UTC.

## 6. Run the app with your keys
Project Settings -> API: copy the Project URL and the `anon` public key.

```bash
flutter run \
  --dart-define=JAMENDO_CLIENT_ID=your_jamendo_id \
  --dart-define=SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=your_anon_key
```

## How the playlists work
- **Daily Mix 1-3:** songs from your 1st, 2nd and 3rd favourite genres.
  Songs you played in the last 3 days are left out. Refreshes every day.
- **Discover Weekly:** songs from your top genres that you have never played or
  liked. Refreshes every Monday.
- **Repeat Rewind:** your most played songs from the last 30 days.
- **Fresh releases / Trending now:** straight from the daily sync.
- A song counts as "played" after 20 seconds of listening.
- New listeners with no history get the most popular genres until the app
  learns their taste.
