// Daily job: pulls new + trending songs from Audius and Jamendo into the `tracks` table.
// Existing songs keep their original `added_at`; only metadata + popularity are refreshed.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const APP = "Tunora";
const db = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);
const SYNC_SECRET = Deno.env.get("SYNC_SECRET") ?? "";
const JAMENDO_ID = Deno.env.get("JAMENDO_CLIENT_ID") ?? "";

const AUDIUS_GENRES = [
  "Electronic", "Pop", "Hip-Hop/Rap", "Rock", "Alternative", "Ambient",
  "Jazz", "Classical", "R&B/Soul", "Lo-Fi", "Metal", "Folk", "Country",
  "Reggae", "Latin", "Funk", "Acoustic", "Soundtrack",
];
const JAMENDO_TAGS = [
  "pop", "rock", "electronic", "hiphop", "jazz", "classical", "ambient",
  "lounge", "metal", "world", "soundtrack", "folk", "reggae", "blues",
];
// Keeps genre names the same across both sources so mixes line up.
const JAMENDO_GENRE_NAMES: Record<string, string> = {
  hiphop: "Hip-Hop/Rap",
  rnb: "R&B/Soul",
  easylistening: "Easy Listening",
  lounge: "Lo-Fi",
};
const BLOCKED_GENRES = new Set([
  "Podcasts", "Spoken Word", "Comedy", "Audiobooks", "Kids",
]);

type Row = {
  track_key: string;
  source: "audius" | "jamendo";
  source_id: string;
  title: string;
  artist: string;
  album: string;
  art_url: string | null;
  stream_url: string | null;
  download_url: string | null;
  downloadable: boolean;
  duration_sec: number | null;
  genre: string | null;
  released_at: string | null;
  popularity: number;
  updated_at: string;
};

const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

function toIso(v: unknown): string | null {
  if (!v) return null;
  const d = new Date(String(v));
  return isNaN(d.getTime()) ? null : d.toISOString();
}

// ---------- Audius ----------
async function audiusHost(): Promise<string> {
  try {
    const r = await fetch("https://api.audius.co");
    const j = await r.json();
    if (Array.isArray(j.data) && j.data.length) return j.data[0];
  } catch (_) { /* fall through */ }
  return "https://discoveryprovider.audius.co";
}

async function audiusTrending(
  host: string,
  params: Record<string, string>,
): Promise<any[]> {
  const q = new URLSearchParams({ app_name: APP, limit: "50", ...params });
  try {
    const r = await fetch(`${host}/v1/tracks/trending?${q}`);
    if (!r.ok) return [];
    return (await r.json()).data ?? [];
  } catch (_) {
    return [];
  }
}

function audiusRow(j: any, popularity: number): Row | null {
  if (!j?.id || j.is_streamable === false) return null;
  const genre: string | null = j.genre ?? null;
  if (genre && BLOCKED_GENRES.has(genre)) return null;
  return {
    track_key: `audius_${j.id}`,
    source: "audius",
    source_id: String(j.id),
    title: j.title ?? "Unknown title",
    artist: j.user?.name ?? "Unknown artist",
    album: "",
    art_url: j.artwork?.["480x480"] ?? j.artwork?.["150x150"] ?? null,
    stream_url: null,
    download_url: null,
    downloadable: j.is_downloadable === true,
    duration_sec: typeof j.duration === "number" ? Math.round(j.duration) : null,
    genre,
    released_at: toIso(j.release_date) ?? toIso(j.created_at),
    popularity,
    updated_at: new Date().toISOString(),
  };
}

// ---------- Jamendo ----------
async function jamendo(params: Record<string, string>): Promise<any[]> {
  if (!JAMENDO_ID) return [];
  const q = new URLSearchParams({
    client_id: JAMENDO_ID,
    format: "json",
    limit: "100",
    audioformat: "mp32",
    audiodlformat: "mp32",
    imagesize: "500",
    include: "musicinfo",
    ...params,
  });
  try {
    const r = await fetch(`https://api.jamendo.com/v3.0/tracks/?${q}`);
    if (!r.ok) return [];
    return (await r.json()).results ?? [];
  } catch (_) {
    return [];
  }
}

function jamendoRow(j: any, popularity: number): Row | null {
  if (!j?.id || !j.audio) return null;
  const g: string | undefined = j.musicinfo?.tags?.genres?.[0];
  const genre = g ? (JAMENDO_GENRE_NAMES[g] ?? cap(g)) : null;
  const canDownload = j.audiodownload_allowed === true && !!j.audiodownload;
  return {
    track_key: `jamendo_${j.id}`,
    source: "jamendo",
    source_id: String(j.id),
    title: j.name ?? "Unknown title",
    artist: j.artist_name ?? "Unknown artist",
    album: j.album_name ?? "",
    art_url: j.image ?? null,
    stream_url: j.audio,
    download_url: canDownload ? j.audiodownload : null,
    downloadable: canDownload,
    duration_sec: typeof j.duration === "number" ? Math.round(j.duration) : null,
    genre,
    released_at: toIso(j.releasedate),
    popularity,
    updated_at: new Date().toISOString(),
  };
}

// ---------- Handler ----------
async function countTracks(): Promise<number> {
  const { count } = await db
    .from("tracks")
    .select("*", { count: "exact", head: true });
  return count ?? 0;
}

Deno.serve(async (req) => {
  if (!SYNC_SECRET || req.headers.get("x-sync-secret") !== SYNC_SECRET) {
    return new Response("Unauthorized", { status: 401 });
  }

  const rows = new Map<string, Row>();
  const add = (r: Row | null) => {
    if (!r) return;
    const old = rows.get(r.track_key);
    if (!old) {
      rows.set(r.track_key, r);
      return;
    }
    if (r.popularity > old.popularity) old.popularity = r.popularity;
    if (!old.genre && r.genre) old.genre = r.genre;
  };
  const rank = (i: number) => Math.max(1, 100 - i * 2);

  const host = await audiusHost();
  const jobs: Promise<void>[] = [];

  jobs.push(
    audiusTrending(host, { time: "week" }).then((l) =>
      l.forEach((j, i) => add(audiusRow(j, rank(i))))
    ),
  );
  for (const genre of AUDIUS_GENRES) {
    jobs.push(
      audiusTrending(host, { time: "month", genre }).then((l) =>
        l.forEach((j, i) => add(audiusRow(j, rank(i))))
      ),
    );
  }

  jobs.push(
    jamendo({ order: "popularity_week" }).then((l) =>
      l.forEach((j, i) => add(jamendoRow(j, rank(i))))
    ),
  );
  jobs.push(
    jamendo({ order: "releasedate_desc" }).then((l) =>
      l.forEach((j) => add(jamendoRow(j, 30)))
    ),
  );
  for (const tags of JAMENDO_TAGS) {
    jobs.push(
      jamendo({ order: "popularity_month", tags, limit: "50" }).then((l) =>
        l.forEach((j, i) => add(jamendoRow(j, rank(i))))
      ),
    );
  }

  await Promise.all(jobs);

  if (rows.size === 0) {
    return Response.json({ ok: false, error: "No songs fetched from sources" }, {
      status: 502,
    });
  }

  const before = await countTracks();
  await db.rpc("decay_popularity");

  const all = [...rows.values()];
  for (let i = 0; i < all.length; i += 500) {
    const { error } = await db
      .from("tracks")
      .upsert(all.slice(i, i + 500), { onConflict: "track_key" });
    if (error) {
      return Response.json({ ok: false, error: error.message }, { status: 500 });
    }
  }
  const after = await countTracks();

  return Response.json({
    ok: true,
    fetched: all.length,
    newSongs: after - before,
    totalSongs: after,
  });
});
