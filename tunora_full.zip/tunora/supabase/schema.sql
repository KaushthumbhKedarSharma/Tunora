-- Tunora backend schema. Run this once in Supabase: SQL Editor -> New query -> Run.

-- ---------- Tables ----------
create table if not exists public.tracks (
  track_key    text primary key,              -- e.g. audius_123 / jamendo_456
  source       text not null check (source in ('audius', 'jamendo')),
  source_id    text not null,
  title        text not null,
  artist       text not null,
  album        text not null default '',
  art_url      text,
  stream_url   text,                          -- Jamendo only (Audius URL is built in the app)
  download_url text,                          -- Jamendo only
  downloadable boolean not null default false,
  duration_sec int,
  genre        text,
  released_at  timestamptz,
  popularity   int not null default 0,
  added_at     timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists tracks_genre_idx on public.tracks (genre);
create index if not exists tracks_added_idx on public.tracks (added_at desc);
create index if not exists tracks_pop_idx   on public.tracks (popularity desc);

create table if not exists public.plays (
  id        bigint generated always as identity primary key,
  user_id   uuid not null default auth.uid(),
  track_key text not null,
  played_at timestamptz not null default now()
);
create index if not exists plays_user_time_idx  on public.plays (user_id, played_at desc);
create index if not exists plays_user_track_idx on public.plays (user_id, track_key);

create table if not exists public.likes (
  user_id   uuid not null default auth.uid(),
  track_key text not null,
  liked_at  timestamptz not null default now(),
  primary key (user_id, track_key)
);

-- ---------- Row level security ----------
alter table public.tracks enable row level security;
alter table public.plays  enable row level security;
alter table public.likes  enable row level security;

drop policy if exists "tracks are public" on public.tracks;
create policy "tracks are public" on public.tracks for select using (true);

drop policy if exists "own plays read"   on public.plays;
drop policy if exists "own plays insert" on public.plays;
create policy "own plays read"   on public.plays for select using (auth.uid() = user_id);
create policy "own plays insert" on public.plays for insert with check (auth.uid() = user_id);

drop policy if exists "own likes read"   on public.likes;
drop policy if exists "own likes insert" on public.likes;
drop policy if exists "own likes delete" on public.likes;
create policy "own likes read"   on public.likes for select using (auth.uid() = user_id);
create policy "own likes insert" on public.likes for insert with check (auth.uid() = user_id);
create policy "own likes delete" on public.likes for delete using (auth.uid() = user_id);

-- ---------- Sync helper (called by the daily job only) ----------
create or replace function public.decay_popularity()
returns void language sql as $$
  update public.tracks set popularity = floor(popularity * 0.8)::int where popularity > 0;
$$;
revoke all on function public.decay_popularity() from public, anon, authenticated;

-- ---------- Taste: your top genres (plays decay over 30 days, likes count extra) ----------
create or replace function public.top_genres(n int default 3)
returns table (genre_name text, pos int)
language plpgsql stable security invoker set search_path = public as $$
begin
  return query
  with signals as (
    select t.genre as g,
           sum(exp(-extract(epoch from (now() - p.played_at)) / 86400.0 / 30.0))::numeric as w
    from plays p
    join tracks t on t.track_key = p.track_key
    where p.user_id = auth.uid()
      and t.genre is not null
      and p.played_at > now() - interval '90 days'
    group by t.genre
    union all
    select t.genre as g, (3 * count(*))::numeric as w
    from likes l
    join tracks t on t.track_key = l.track_key
    where l.user_id = auth.uid()
      and t.genre is not null
    group by t.genre
  ),
  ranked as (
    select s.g, sum(s.w) as score from signals s group by s.g
  )
  select r.g, (row_number() over (order by r.score desc))::int
  from ranked r
  order by r.score desc
  limit n;

  -- New listener with no history: fall back to the most popular genres.
  if not found then
    return query
    select r.g, (row_number() over (order by r.score desc))::int
    from (
      select t.genre as g, sum(t.popularity) as score
      from tracks t
      where t.genre is not null
      group by t.genre
    ) r
    order by r.score desc
    limit n;
  end if;
end;
$$;

-- ---------- Playlists ----------
-- Newest songs first.
create or replace function public.new_releases(lim int default 30)
returns setof public.tracks
language sql stable security invoker set search_path = public as $$
  select t.* from tracks t
  order by coalesce(t.released_at, t.added_at) desc
  limit lim;
$$;

-- Most popular songs right now.
create or replace function public.trending_tracks(lim int default 30)
returns setof public.tracks
language sql stable security invoker set search_path = public as $$
  select t.* from tracks t
  order by t.popularity desc, t.added_at desc
  limit lim;
$$;

-- Daily Mix N = songs from your Nth favourite genre, skipping anything played in the last 3 days.
create or replace function public.daily_mix(mix_no int default 1, lim int default 30)
returns setof public.tracks
language sql volatile security invoker set search_path = public as $$
  select t.* from tracks t
  where t.genre = (select tg.genre_name from top_genres(mix_no) tg where tg.pos = mix_no)
    and not exists (
      select 1 from plays p
      where p.user_id = auth.uid()
        and p.track_key = t.track_key
        and p.played_at > now() - interval '3 days'
    )
  order by random() * (t.popularity + 50) desc
  limit lim;
$$;

-- Discover Weekly = songs from your top genres that you have never played or liked.
create or replace function public.discover_weekly(lim int default 30)
returns setof public.tracks
language sql volatile security invoker set search_path = public as $$
  select t.* from tracks t
  where t.genre in (select tg.genre_name from top_genres(5) tg)
    and not exists (
      select 1 from plays p
      where p.user_id = auth.uid() and p.track_key = t.track_key
    )
    and not exists (
      select 1 from likes l
      where l.user_id = auth.uid() and l.track_key = t.track_key
    )
  order by random() * (t.popularity + 50) desc
  limit lim;
$$;

-- Repeat Rewind = what you played most in the last 30 days.
create or replace function public.repeat_rewind(lim int default 30)
returns setof public.tracks
language sql stable security invoker set search_path = public as $$
  select t.*
  from tracks t
  join (
    select p.track_key, count(*) as c
    from plays p
    where p.user_id = auth.uid()
      and p.played_at > now() - interval '30 days'
    group by p.track_key
  ) pc on pc.track_key = t.track_key
  order by pc.c desc
  limit lim;
$$;
