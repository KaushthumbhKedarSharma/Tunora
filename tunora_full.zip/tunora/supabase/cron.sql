-- Runs the music sync every day at 03:00 UTC.
-- 1) Replace YOUR_PROJECT_REF and YOUR_SYNC_SECRET below.
-- 2) Run in Supabase: SQL Editor -> New query -> Run.

create extension if not exists pg_cron;
create extension if not exists pg_net;

select cron.schedule(
  'tunora-sync-music',
  '0 3 * * *',
  $$
  select net.http_post(
    url     := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/sync-music',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'x-sync-secret', 'YOUR_SYNC_SECRET'
    ),
    body    := '{}'::jsonb
  );
  $$
);

-- To stop the job later:  select cron.unschedule('tunora-sync-music');
