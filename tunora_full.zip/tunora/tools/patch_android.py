"""Applies the Android settings Tunora needs (background playback, permissions)
to a freshly generated Flutter Android project.  Usage: patch_android.py <app_dir>"""
import pathlib
import re
import sys

root = pathlib.Path(sys.argv[1])

# ---------- AndroidManifest.xml ----------
manifest = root / "android/app/src/main/AndroidManifest.xml"
m = manifest.read_text()

if "xmlns:tools" not in m:
    m = m.replace("<manifest ", '<manifest xmlns:tools="http://schemas.android.com/tools" ', 1)

if "FOREGROUND_SERVICE_MEDIA_PLAYBACK" not in m:
    perms = """    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
"""
    m = m.replace("<application", perms + "    <application", 1)

if "com.ryanheise.audioservice.AudioService" not in m:
    service = """
        <service
            android:name="com.ryanheise.audioservice.AudioService"
            android:foregroundServiceType="mediaPlayback"
            android:exported="true"
            tools:ignore="Instantiatable">
            <intent-filter>
                <action android:name="android.media.browse.MediaBrowserService"/>
            </intent-filter>
        </service>

        <receiver
            android:name="com.ryanheise.audioservice.MediaButtonReceiver"
            android:exported="true"
            tools:ignore="Instantiatable">
            <intent-filter>
                <action android:name="android.intent.action.MEDIA_BUTTON"/>
            </intent-filter>
        </receiver>
    """
    m = m.replace("</application>", service + "</application>", 1)

m = re.sub(r'android:label="[^"]*"', 'android:label="Tunora"', m, count=1)
manifest.write_text(m)
print("patched AndroidManifest.xml")

# ---------- MainActivity ----------
done = False
for f in (root / "android/app/src/main").rglob("MainActivity.kt"):
    text = f.read_text()
    pkg = re.search(r"^package\s+[\w.]+", text, re.M).group(0)
    f.write_text(
        f"{pkg}\n\nimport com.ryanheise.audioservice.AudioServiceActivity\n\n"
        "class MainActivity : AudioServiceActivity()\n"
    )
    print("patched", f)
    done = True
if not done:
    sys.exit("MainActivity.kt not found")

# ---------- minSdk ----------
changed = False
for name in ("build.gradle.kts", "build.gradle"):
    f = root / "android/app" / name
    if f.exists():
        t = f.read_text()
        new = re.sub(r"minSdk(Version)?\s*=?\s*flutter\.minSdkVersion", "minSdk = 23", t)
        if new != t:
            f.write_text(new)
            changed = True
            print("patched", f)
if not changed:
    print("WARNING: minSdk line not found; check android/app/build.gradle")
