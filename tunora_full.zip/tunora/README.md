# Tunora (phase 1)

Spotify-style free music app for Android, built with Flutter.

**Included:** Home / Search / Your Library, mini player, full-screen player,
background playback with notification + lock-screen controls, equalizer with
presets + volume boost, liked songs, downloads (where the artist allows it),
Audius + Jamendo as music sources.

**Phase 2 (included):** daily auto-update of new songs and auto-generated
playlists (Daily Mix 1-3, Discover Weekly, Repeat Rewind, Fresh Releases)
using Supabase. Set it up with `supabase/SETUP.md`. The app still works
without Supabase (it then loads songs live from Audius/Jamendo and shows no
"Made for you" playlists).

## 1. Create the Android project

Install Flutter (3.24 or newer), then:

```bash
flutter create --org com.tunora --project-name tunora --platforms android tunora_app
cd tunora_app
```

Copy the `lib/` folder and `pubspec.yaml` from this zip over the generated
ones, then run `flutter pub get`.

## 2. Android setup (needed for background playback)

**android/app/build.gradle(.kts)**: set `minSdk` to 23 or higher.

**android/app/src/main/AndroidManifest.xml**

Add `xmlns:tools="http://schemas.android.com/tools"` to the `<manifest ...>` tag.

Add these above `<application>`:

```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.WAKE_LOCK"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
```

Set `android:label="Tunora"` on `<application>`, and add these inside it:

```xml
<service
    android:name="com.ryanheise.audioservice.AudioService"
    android:foregroundServiceType="mediaPlayback"
    android:exported="true"
    tools:ignore="Instantiatable">
    <intent-filter>
        <action android:name="android.media.browse.MediaBrowserService"/>
    </intent-filter>
</service>

<receiver
    android:name="com.ryanheise.audioservice.MediaButtonReceiver"
    android:exported="true"
    tools:ignore="Instantiatable">
    <intent-filter>
        <action android:name="android.intent.action.MEDIA_BUTTON"/>
    </intent-filter>
</receiver>
```

**MainActivity** (`android/app/src/main/kotlin/.../MainActivity.kt`):

```kotlin
package com.tunora.tunora

import com.ryanheise.audioservice.AudioServiceActivity

class MainActivity : AudioServiceActivity()
```

(Keep the `package` line the generated file already has.)

## 3. Run

Get a free client id at https://developer.jamendo.com, then:

```bash
flutter run \
  --dart-define=JAMENDO_CLIENT_ID=your_client_id \
  --dart-define=SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=your_anon_key
```

Without the Jamendo id the app uses Audius only. Without the Supabase values
it skips the auto playlists. Backend setup: `supabase/SETUP.md`.

## Licensing notes

- Jamendo's free API is for non-commercial use. Get a commercial license
  before monetizing.
- Download buttons only work for songs whose artist allows downloads.
- Use your own app name and logo. Do not use Spotify's logo or branding.
