import 'package:flutter/material.dart';
import '../app_state.dart';
import '../models/auto_playlist.dart';
import '../models/track.dart';
import '../theme.dart';
import '../widgets/track_tile.dart';
import 'playlist_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<List<Track>> _trending = catalog.trending();
  late Future<List<Track>> _fresh = catalog.freshReleases();
  late Future<List<AutoPlaylist>> _made = backend.homePlaylists();

  String get _greeting {
    final h = DateTime.now().hour;
    if (h < 12) return 'Good morning';
    if (h < 18) return 'Good afternoon';
    return 'Good evening';
  }

  Future<void> _refresh() async {
    setState(() {
      _trending = catalog.trending();
      _fresh = catalog.freshReleases();
      _made = backend.homePlaylists();
    });
    await Future.wait([_trending, _fresh, _made]);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: RefreshIndicator(
        color: TunoraColors.green,
        onRefresh: _refresh,
        child: ListView(
          padding: const EdgeInsets.only(bottom: 16),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
              child: Text(_greeting,
                  style: const TextStyle(
                      fontSize: 24, fontWeight: FontWeight.w800)),
            ),
            FutureBuilder<List<AutoPlaylist>>(
              future: _made,
              builder: (context, snap) {
                final lists = snap.data;
                if (lists == null || lists.isEmpty) {
                  return const SizedBox.shrink();
                }
                return _MadeForYou(playlists: lists);
              },
            ),
            FutureBuilder<List<Track>>(
              future: _trending,
              builder: (context, snap) {
                final tracks = snap.data;
                if (snap.connectionState != ConnectionState.done) {
                  return const _Loading(height: 240);
                }
                if (tracks == null || tracks.isEmpty) {
                  return const _Empty();
                }
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _QuickPicks(tracks: tracks.take(6).toList()),
                    _Section(title: 'Trending now', tracks: tracks),
                  ],
                );
              },
            ),
            FutureBuilder<List<Track>>(
              future: _fresh,
              builder: (context, snap) {
                final tracks = snap.data;
                if (tracks == null || tracks.isEmpty) {
                  return const SizedBox.shrink();
                }
                return _Section(title: 'Fresh releases', tracks: tracks);
              },
            ),
            if (!catalog.jamendoEnabled)
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 24, 16, 0),
                child: Text(
                  'Showing Audius music only. Add a Jamendo client id to include Jamendo songs too.',
                  style: TextStyle(
                      fontSize: 12, color: TunoraColors.textSecondary),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _QuickPicks extends StatelessWidget {
  final List<Track> tracks;
  const _QuickPicks({required this.tracks});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: tracks.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisExtent: 56,
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
        ),
        itemBuilder: (_, i) => Material(
          color: TunoraColors.card,
          borderRadius: BorderRadius.circular(4),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: () => playList(tracks, i),
            child: Row(
              children: [
                TrackArt(url: tracks[i].artUrl, size: 56, radius: 0),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    tracks[i].title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 13, fontWeight: FontWeight.w700),
                  ),
                ),
                const SizedBox(width: 6),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  final List<Track> tracks;
  const _Section({required this.title, required this.tracks});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
          child: Text(title,
              style:
                  const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        ),
        SizedBox(
          height: 210,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: tracks.length,
            separatorBuilder: (_, __) => const SizedBox(width: 14),
            itemBuilder: (_, i) => GestureDetector(
              onTap: () => playList(tracks, i),
              child: SizedBox(
                width: 150,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TrackArt(url: tracks[i].artUrl, size: 150),
                    const SizedBox(height: 8),
                    Text(tracks[i].title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 14)),
                    Text(tracks[i].artist,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            color: TunoraColors.textSecondary, fontSize: 12)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _Loading extends StatelessWidget {
  final double height;
  const _Loading({required this.height});

  @override
  Widget build(BuildContext context) => SizedBox(
        height: height,
        child: const Center(
            child: CircularProgressIndicator(color: TunoraColors.green)),
      );
}

class _Empty extends StatelessWidget {
  const _Empty();

  @override
  Widget build(BuildContext context) => const Padding(
        padding: EdgeInsets.all(32),
        child: Text(
          'Could not load songs. Check your internet connection, then pull down to try again.',
          textAlign: TextAlign.center,
          style: TextStyle(color: TunoraColors.textSecondary),
        ),
      );
}


class _MadeForYou extends StatelessWidget {
  final List<AutoPlaylist> playlists;
  const _MadeForYou({required this.playlists});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 4, 16, 12),
          child: Text('Made for you',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        ),
        SizedBox(
          height: 236,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: playlists.length,
            separatorBuilder: (_, __) => const SizedBox(width: 14),
            itemBuilder: (context, i) {
              final p = playlists[i];
              return GestureDetector(
                onTap: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => PlaylistScreen(playlist: p))),
                child: SizedBox(
                  width: 150,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Stack(
                        children: [
                          TrackArt(url: p.coverUrl, size: 150),
                          Positioned.fill(
                            child: DecoratedBox(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                gradient: const LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [Colors.transparent, Color(0xCC000000)],
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 10,
                            right: 10,
                            bottom: 10,
                            child: Text(p.title,
                                style: const TextStyle(
                                    fontSize: 17, fontWeight: FontWeight.w800)),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(p.subtitle,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: TunoraColors.textSecondary, fontSize: 12)),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
