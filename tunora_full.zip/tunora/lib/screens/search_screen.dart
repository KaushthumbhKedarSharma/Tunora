import 'package:flutter/material.dart';
import '../app_state.dart';
import '../models/track.dart';
import '../theme.dart';
import '../widgets/track_tile.dart';

const _genres = <String, Color>{
  'Pop': Color(0xFFE13300),
  'Hip-Hop': Color(0xFFBC5900),
  'Electronic': Color(0xFF8D67AB),
  'Rock': Color(0xFFE91429),
  'Lo-fi': Color(0xFF477D95),
  'Chill': Color(0xFF1E3264),
  'Jazz': Color(0xFF7D4B32),
  'Classical': Color(0xFF509BF5),
  'Ambient': Color(0xFF2D46B9),
  'Indie': Color(0xFF608108),
};

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _controller = TextEditingController();
  Future<List<Track>>? _results;

  void _search(String q) {
    final query = q.trim();
    if (query.isEmpty) {
      setState(() => _results = null);
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() => _results = catalog.search(query));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 12),
            child: Text('Search',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              controller: _controller,
              textInputAction: TextInputAction.search,
              onSubmitted: _search,
              style: const TextStyle(color: Colors.black),
              cursorColor: Colors.black,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.white,
                hintText: 'What do you want to listen to?',
                hintStyle: const TextStyle(
                    color: Color(0xFF535353), fontWeight: FontWeight.w600),
                prefixIcon: const Icon(Icons.search, color: Colors.black),
                suffixIcon: _controller.text.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.close, color: Colors.black),
                        onPressed: () {
                          _controller.clear();
                          _search('');
                        },
                      ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(6),
                  borderSide: BorderSide.none,
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onChanged: (_) => setState(() {}),
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: _results == null ? _browse() : _resultList(),
          ),
        ],
      ),
    );
  }

  Widget _browse() => ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        children: [
          const Padding(
            padding: EdgeInsets.only(bottom: 12),
            child: Text('Browse all',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          ),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.7,
            children: [
              for (final g in _genres.entries)
                GestureDetector(
                  onTap: () {
                    _controller.text = g.key;
                    _search(g.key);
                  },
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: g.value,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(g.key,
                        style: const TextStyle(
                            fontSize: 17, fontWeight: FontWeight.w800)),
                  ),
                ),
            ],
          ),
        ],
      );

  Widget _resultList() => FutureBuilder<List<Track>>(
        future: _results,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(
                child: CircularProgressIndicator(color: TunoraColors.green));
          }
          final tracks = snap.data ?? [];
          if (tracks.isEmpty) {
            return const Center(
              child: Text('No songs found. Try a different name or genre.',
                  style: TextStyle(color: TunoraColors.textSecondary)),
            );
          }
          return ListView.builder(
            itemCount: tracks.length,
            itemBuilder: (_, i) => TrackTile(tracks: tracks, index: i),
          );
        },
      );
}
