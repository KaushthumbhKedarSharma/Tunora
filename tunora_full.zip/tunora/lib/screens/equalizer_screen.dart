import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../app_state.dart';
import '../theme.dart';

/// Preset curves: 5 points from low to high frequency, 0.5 = flat.
const Map<String, List<double>> _presets = {
  'Flat': [0.5, 0.5, 0.5, 0.5, 0.5],
  'Bass Boost': [0.9, 0.75, 0.5, 0.5, 0.5],
  'Rock': [0.75, 0.6, 0.45, 0.62, 0.75],
  'Pop': [0.42, 0.58, 0.7, 0.58, 0.42],
  'Classical': [0.65, 0.58, 0.5, 0.58, 0.68],
  'Vocal': [0.35, 0.45, 0.7, 0.7, 0.55],
};

class EqualizerScreen extends StatefulWidget {
  const EqualizerScreen({super.key});

  @override
  State<EqualizerScreen> createState() => _EqualizerScreenState();
}

class _EqualizerScreenState extends State<EqualizerScreen> {
  double _boost = 0;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (mounted) setState(() => _boost = p.getDouble('eq_boost') ?? 0);
    });
  }

  Future<void> _saveGains(AndroidEqualizerParameters params) async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList(
        'eq_gains', params.bands.map((b) => b.gain.toString()).toList());
  }

  Future<void> _setEnabled(bool v) async {
    await audioHandler.equalizer.setEnabled(v);
    final p = await SharedPreferences.getInstance();
    await p.setBool('eq_enabled', v);
  }

  Future<void> _applyPreset(
      AndroidEqualizerParameters params, List<double> curve) async {
    final n = params.bands.length;
    for (var i = 0; i < n; i++) {
      final pos = n == 1 ? 0.0 : i / (n - 1) * (curve.length - 1);
      final lo = pos.floor();
      final hi = pos.ceil() > curve.length - 1 ? curve.length - 1 : pos.ceil();
      final v = curve[lo] + (curve[hi] - curve[lo]) * (pos - lo);
      final gain =
          params.minDecibels + v * (params.maxDecibels - params.minDecibels);
      await params.bands[i].setGain(gain);
    }
    await _saveGains(params);
  }

  Future<void> _setBoost(double v) async {
    setState(() => _boost = v);
    await audioHandler.loudness.setTargetGain(v);
    await audioHandler.loudness.setEnabled(v > 0);
  }

  Future<void> _saveBoost() async {
    final p = await SharedPreferences.getInstance();
    await p.setDouble('eq_boost', _boost);
  }

  String _freq(double hz) => hz >= 1000
      ? '${(hz / 1000).toStringAsFixed(hz % 1000 == 0 ? 0 : 1)}k'
      : '${hz.round()}';

  @override
  Widget build(BuildContext context) {
    final loaded = audioHandler.player.audioSource != null;
    return Scaffold(
      appBar: AppBar(title: const Text('Equalizer')),
      body: !loaded
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text(
                  'Play a song first, then come back to adjust the sound.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: TunoraColors.textSecondary),
                ),
              ),
            )
          : FutureBuilder<AndroidEqualizerParameters>(
              future: audioHandler.equalizer.parameters,
              builder: (context, snap) {
                final params = snap.data;
                if (params == null) {
                  return const Center(child: CircularProgressIndicator());
                }
                return ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    StreamBuilder<bool>(
                      stream: audioHandler.equalizer.enabledStream,
                      builder: (_, s) => SwitchListTile(
                        title: const Text('Equalizer',
                            style: TextStyle(fontWeight: FontWeight.w600)),
                        value: s.data ?? false,
                        activeColor: TunoraColors.green,
                        onChanged: _setEnabled,
                      ),
                    ),
                    SizedBox(
                      height: 44,
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        children: [
                          for (final e in _presets.entries)
                            Padding(
                              padding: const EdgeInsets.only(right: 8),
                              child: ActionChip(
                                label: Text(e.key),
                                backgroundColor: TunoraColors.card,
                                onPressed: () async {
                                  await _setEnabled(true);
                                  await _applyPreset(params, e.value);
                                },
                              ),
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      height: 260,
                      child: Row(
                        children: [
                          for (final band in params.bands)
                            Expanded(
                              child: Column(
                                children: [
                                  Expanded(
                                    child: StreamBuilder<double>(
                                      stream: band.gainStream,
                                      builder: (_, s) => RotatedBox(
                                        quarterTurns: 3,
                                        child: Slider(
                                          min: params.minDecibels,
                                          max: params.maxDecibels,
                                          value: (s.data ?? band.gain)
                                              .clamp(params.minDecibels,
                                                  params.maxDecibels)
                                              .toDouble(),
                                          activeColor: TunoraColors.green,
                                          onChanged: band.setGain,
                                          onChangeEnd: (_) async {
                                            await _setEnabled(true);
                                            await _saveGains(params);
                                          },
                                        ),
                                      ),
                                    ),
                                  ),
                                  Text('${_freq(band.centerFrequency)} Hz',
                                      style: const TextStyle(
                                          fontSize: 11,
                                          color: TunoraColors.textSecondary)),
                                ],
                              ),
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),
                    const Text('Volume boost',
                        style: TextStyle(fontWeight: FontWeight.w600)),
                    Slider(
                      min: 0,
                      max: 6,
                      divisions: 12,
                      value: _boost,
                      label: '+${_boost.toStringAsFixed(1)} dB',
                      activeColor: TunoraColors.green,
                      onChanged: _setBoost,
                      onChangeEnd: (_) => _saveBoost(),
                    ),
                    const Text(
                      'High boost can distort quiet tracks. Lower it if the sound crackles.',
                      style: TextStyle(
                          fontSize: 12, color: TunoraColors.textSecondary),
                    ),
                  ],
                );
              },
            ),
    );
  }
}
