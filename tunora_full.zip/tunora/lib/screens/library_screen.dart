import 'package:flutter/material.dart';
import '../app_state.dart';
import '../models/track.dart';
import '../theme.dart';
import '../widgets/track_tile.dart';

class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: DefaultTabController(
        length: 2,
        child: Column(
          children: [
            const Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.fromLTRB(16, 16, 16, 4),
                child: Text('Your Library',
                    style:
                        TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
              ),
            ),
            const TabBar(
              indicatorColor: TunoraColors.green,
              labelColor: Colors.white,
              unselectedLabelColor: TunoraColors.textSecondary,
              tabs: [Tab(text: 'Liked songs'), Tab(text: 'Downloads')],
            ),
            Expanded(
              child: ListenableBuilder(
                listenable: library,
                builder: (context, _) => TabBarView(
                  children: [
                    _List(
                      tracks: library.liked,
                      empty: 'Tap the heart on a song to save it here.',
                    ),
                    _List(
                      tracks: library.downloads,
                      empty:
                          'Downloaded songs appear here and play without internet.',
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _List extends StatelessWidget {
  final List<Track> tracks;
  final String empty;
  const _List({required this.tracks, required this.empty});

  @override
  Widget build(BuildContext context) {
    if (tracks.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(empty,
              textAlign: TextAlign.center,
              style: const TextStyle(color: TunoraColors.textSecondary)),
        ),
      );
    }
    return ListView.builder(
      itemCount: tracks.length,
      itemBuilder: (_, i) => TrackTile(tracks: tracks, index: i),
    );
  }
}
