import 'package:audio_service/audio_service.dart';
import 'package:flutter/material.dart';
import 'package:rxdart/rxdart.dart';
import '../app_state.dart';
import '../theme.dart';
import '../widgets/seek_bar.dart';
import '../widgets/track_tile.dart';
import 'equalizer_screen.dart';

void openPlayer(BuildContext context) {
  Navigator.of(context).push(PageRouteBuilder(
    opaque: true,
    transitionDuration: const Duration(milliseconds: 280),
    pageBuilder: (_, __, ___) => const PlayerScreen(),
    transitionsBuilder: (_, anim, __, child) => SlideTransition(
      position: Tween(begin: const Offset(0, 1), end: Offset.zero)
          .chain(CurveTween(curve: Curves.easeOutCubic))
          .animate(anim),
      child: child,
    ),
  ));
}

class _Pos {
  final Duration position;
  final MediaItem? item;
  _Pos(this.position, this.item);
}

class PlayerScreen extends StatelessWidget {
  const PlayerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF4A3A3A), TunoraColors.background],
            stops: [0.0, 0.75],
          ),
        ),
        child: SafeArea(
          child: StreamBuilder<MediaItem?>(
            stream: audioHandler.mediaItem,
            builder: (context, snap) {
              final item = snap.data;
              if (item == null) return const SizedBox.shrink();
              final track = audioHandler.trackFor(item.id);
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 22),
                child: Column(
                  children: [
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.keyboard_arrow_down, size: 32),
                          onPressed: () => Navigator.of(context).pop(),
                        ),
                        const Expanded(
                          child: Text(
                            'Playing from Tunora',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 13, fontWeight: FontWeight.w600),
                          ),
                        ),
                        IconButton(
                          tooltip: 'Equalizer',
                          icon: const Icon(Icons.equalizer),
                          onPressed: () => Navigator.of(context).push(
                            MaterialPageRoute(
                                builder: (_) => const EqualizerScreen()),
                          ),
                        ),
                      ],
                    ),
                    const Spacer(),
                    AspectRatio(
                      aspectRatio: 1,
                      child: LayoutBuilder(
                        builder: (_, c) => TrackArt(
                            url: item.artUri?.toString(),
                            size: c.maxWidth,
                            radius: 8),
                      ),
                    ),
                    const Spacer(),
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(item.title,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      fontSize: 22,
                                      fontWeight: FontWeight.w700)),
                              const SizedBox(height: 2),
                              Text(item.artist ?? '',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      fontSize: 16,
                                      color: TunoraColors.textSecondary)),
                            ],
                          ),
                        ),
                        if (track != null) ...[
                          ListenableBuilder(
                            listenable: library,
                            builder: (_, __) => IconButton(
                              iconSize: 28,
                              icon: Icon(
                                library.isLiked(track)
                                    ? Icons.favorite
                                    : Icons.favorite_border,
                                color: library.isLiked(track)
                                    ? TunoraColors.green
                                    : Colors.white,
                              ),
                              onPressed: () => library.toggleLike(track),
                            ),
                          ),
                          DownloadButton(track: track, size: 28),
                        ],
                      ],
                    ),
                    const SizedBox(height: 8),
                    StreamBuilder<_Pos>(
                      stream: Rx.combineLatest2<Duration, MediaItem?, _Pos>(
                        AudioService.position,
                        audioHandler.mediaItem,
                        (p, i) => _Pos(p, i),
                      ),
                      builder: (_, s) => SeekBar(
                        duration: item.duration ?? Duration.zero,
                        position: s.data?.position ?? Duration.zero,
                        onSeek: audioHandler.seek,
                      ),
                    ),
                    const _Controls(),
                    const SizedBox(height: 24),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class _Controls extends StatelessWidget {
  const _Controls();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<PlaybackState>(
      stream: audioHandler.playbackState,
      builder: (context, snap) {
        final st = snap.data;
        final playing = st?.playing ?? false;
        final loading = st?.processingState == AudioProcessingState.loading ||
            st?.processingState == AudioProcessingState.buffering;
        final shuffle = st?.shuffleMode == AudioServiceShuffleMode.all;
        final repeat = st?.repeatMode ?? AudioServiceRepeatMode.none;
        return Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton(
              icon: Icon(Icons.shuffle,
                  color: shuffle ? TunoraColors.green : Colors.white),
              onPressed: () => audioHandler.setShuffleMode(shuffle
                  ? AudioServiceShuffleMode.none
                  : AudioServiceShuffleMode.all),
            ),
            IconButton(
              iconSize: 40,
              icon: const Icon(Icons.skip_previous),
              onPressed: audioHandler.skipToPrevious,
            ),
            Container(
              width: 68,
              height: 68,
              decoration: const BoxDecoration(
                  color: Colors.white, shape: BoxShape.circle),
              child: loading
                  ? const Padding(
                      padding: EdgeInsets.all(20),
                      child: CircularProgressIndicator(
                          strokeWidth: 3, color: Colors.black),
                    )
                  : IconButton(
                      iconSize: 40,
                      color: Colors.black,
                      icon: Icon(playing ? Icons.pause : Icons.play_arrow),
                      onPressed:
                          playing ? audioHandler.pause : audioHandler.play,
                    ),
            ),
            IconButton(
              iconSize: 40,
              icon: const Icon(Icons.skip_next),
              onPressed: audioHandler.skipToNext,
            ),
            IconButton(
              icon: Icon(
                repeat == AudioServiceRepeatMode.one
                    ? Icons.repeat_one
                    : Icons.repeat,
                color: repeat == AudioServiceRepeatMode.none
                    ? Colors.white
                    : TunoraColors.green,
              ),
              onPressed: () => audioHandler.setRepeatMode(
                repeat == AudioServiceRepeatMode.none
                    ? AudioServiceRepeatMode.all
                    : repeat == AudioServiceRepeatMode.all
                        ? AudioServiceRepeatMode.one
                        : AudioServiceRepeatMode.none,
              ),
            ),
          ],
        );
      },
    );
  }
}
