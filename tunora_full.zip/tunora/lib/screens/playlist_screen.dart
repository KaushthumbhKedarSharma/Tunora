import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../app_state.dart';
import '../models/auto_playlist.dart';
import '../theme.dart';
import '../widgets/mini_player.dart';
import '../widgets/track_tile.dart';

class PlaylistScreen extends StatelessWidget {
  final AutoPlaylist playlist;
  const PlaylistScreen({super.key, required this.playlist});

  @override
  Widget build(BuildContext context) {
    final cover = playlist.coverUrl;
    return Scaffold(
      bottomNavigationBar: const SafeArea(child: MiniPlayer()),
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            expandedHeight: 300,
            backgroundColor: TunoraColors.background,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(playlist.title,
                  style: const TextStyle(fontWeight: FontWeight.w800)),
              background: Stack(
                fit: StackFit.expand,
                children: [
                  if (cover != null)
                    CachedNetworkImage(
                      imageUrl: cover,
                      fit: BoxFit.cover,
                      errorWidget: (_, __, ___) =>
                          Container(color: TunoraColors.card),
                    )
                  else
                    Container(color: TunoraColors.card),
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Color(0x33000000), TunoraColors.background],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      playlist.subtitle,
                      style: const TextStyle(
                          color: TunoraColors.textSecondary, fontSize: 13),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Shuffle',
                    icon: const Icon(Icons.shuffle,
                        color: TunoraColors.textSecondary),
                    onPressed: () {
                      final shuffled = [...playlist.tracks]..shuffle();
                      playList(shuffled, 0);
                    },
                  ),
                  Container(
                    width: 52,
                    height: 52,
                    decoration: const BoxDecoration(
                        color: TunoraColors.green, shape: BoxShape.circle),
                    child: IconButton(
                      iconSize: 32,
                      color: Colors.black,
                      icon: const Icon(Icons.play_arrow),
                      onPressed: () => playList(playlist.tracks, 0),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (_, i) => TrackTile(tracks: playlist.tracks, index: i),
              childCount: playlist.tracks.length,
            ),
          ),
        ],
      ),
    );
  }
}
