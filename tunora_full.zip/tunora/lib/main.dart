import 'package:audio_service/audio_service.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'app_state.dart';
import 'screens/home_screen.dart';
import 'screens/library_screen.dart';
import 'screens/search_screen.dart';
import 'services/audio_handler.dart';
import 'services/audius_service.dart';
import 'theme.dart';
import 'widgets/mini_player.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await library.init();
  await Future.wait([AudiusService.warmUp(), backend.init()]);
  audioHandler = await AudioService.init(
    builder: () => TunoraAudioHandler(),
    config: const AudioServiceConfig(
      androidNotificationChannelId: 'com.tunora.app.playback',
      androidNotificationChannelName: 'Tunora playback',
      androidNotificationOngoing: true,
    ),
  );
  // Listening history + likes feed the auto playlists.
  audioHandler.onPlayCounted = backend.logPlay;
  library.onLikeChanged = backend.setLiked;
  backend.syncLikes(library.liked);
  runApp(const TunoraApp());
}

class TunoraApp extends StatelessWidget {
  const TunoraApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Tunora',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        home: const Shell(),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _index = 0;

  @override
  void initState() {
    super.initState();
    // Android 13+: needed to show the playback notification.
    Permission.notification.request();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: const [HomeScreen(), SearchScreen(), LibraryScreen()],
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const MiniPlayer(),
          NavigationBar(
            selectedIndex: _index,
            onDestinationSelected: (i) => setState(() => _index = i),
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.home_outlined),
                selectedIcon: Icon(Icons.home_filled),
                label: 'Home',
              ),
              NavigationDestination(
                icon: Icon(Icons.search),
                selectedIcon: Icon(Icons.search),
                label: 'Search',
              ),
              NavigationDestination(
                icon: Icon(Icons.library_music_outlined),
                selectedIcon: Icon(Icons.library_music),
                label: 'Your Library',
              ),
            ],
          ),
        ],
      ),
    );
  }
}
