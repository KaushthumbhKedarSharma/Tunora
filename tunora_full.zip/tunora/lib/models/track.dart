import 'package:audio_service/audio_service.dart';

enum TrackSource { audius, jamendo }

class Track {
  final String id;
  final TrackSource source;
  final String title;
  final String artist;
  final String album;
  final String? artUrl;
  final String streamUrl;
  final Duration? duration;
  final String? downloadUrl; // null = artist/license does not allow download

  const Track({
    required this.id,
    required this.source,
    required this.title,
    required this.artist,
    this.album = '',
    this.artUrl,
    required this.streamUrl,
    this.duration,
    this.downloadUrl,
  });

  String get key => '${source.name}_$id';
  bool get canDownload => downloadUrl != null;

  MediaItem toMediaItem({String? localPath}) => MediaItem(
        id: key,
        title: title,
        artist: artist,
        album: album,
        artUri: artUrl != null ? Uri.parse(artUrl!) : null,
        duration: duration,
        extras: {'url': localPath ?? streamUrl, 'local': localPath != null},
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'source': source.name,
        'title': title,
        'artist': artist,
        'album': album,
        'artUrl': artUrl,
        'streamUrl': streamUrl,
        'duration': duration?.inSeconds,
        'downloadUrl': downloadUrl,
      };

  factory Track.fromJson(Map<String, dynamic> j) => Track(
        id: j['id'] as String,
        source: TrackSource.values.byName(j['source'] as String),
        title: j['title'] as String,
        artist: j['artist'] as String,
        album: (j['album'] as String?) ?? '',
        artUrl: j['artUrl'] as String?,
        streamUrl: j['streamUrl'] as String,
        duration:
            j['duration'] != null ? Duration(seconds: j['duration'] as int) : null,
        downloadUrl: j['downloadUrl'] as String?,
      );
}
