import 'track.dart';

class AutoPlaylist {
  final String id;
  final String title;
  final String subtitle;
  final List<Track> tracks;

  const AutoPlaylist({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.tracks,
  });

  String? get coverUrl {
    for (final t in tracks) {
      if (t.artUrl != null) return t.artUrl;
    }
    return null;
  }
}
