import 'package:audio_service/audio_service.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../app_state.dart';
import '../models/track.dart';
import '../theme.dart';
import 'now_playing_bars.dart';

class TrackArt extends StatelessWidget {
  final String? url;
  final double size;
  final double radius;
  const TrackArt({super.key, this.url, required this.size, this.radius = 4});

  @override
  Widget build(BuildContext context) {
    final placeholder = Container(
      width: size,
      height: size,
      color: TunoraColors.card,
      child: Icon(Icons.music_note,
          color: TunoraColors.textSecondary, size: size * 0.4),
    );
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: url == null
          ? placeholder
          : CachedNetworkImage(
              imageUrl: url!,
              width: size,
              height: size,
              fit: BoxFit.cover,
              placeholder: (_, __) => placeholder,
              errorWidget: (_, __, ___) => placeholder,
            ),
    );
  }
}

/// A song row: art, title, artist, like + download buttons.
class TrackTile extends StatelessWidget {
  final List<Track> tracks;
  final int index;
  const TrackTile({super.key, required this.tracks, required this.index});

  Track get track => tracks[index];

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<MediaItem?>(
      stream: audioHandler.mediaItem,
      builder: (context, snap) {
        final isCurrent = snap.data?.id == track.key;
        return ListenableBuilder(
          listenable: library,
          builder: (context, _) => ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 16),
            leading: TrackArt(url: track.artUrl, size: 48),
            title: Text(
              track.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: isCurrent ? TunoraColors.green : Colors.white,
                fontWeight: FontWeight.w500,
              ),
            ),
            subtitle: Text(
              track.artist,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: TunoraColors.textSecondary),
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (isCurrent)
                  StreamBuilder<PlaybackState>(
                    stream: audioHandler.playbackState,
                    builder: (_, s) =>
                        NowPlayingBars(animate: s.data?.playing ?? false),
                  ),
                IconButton(
                  icon: Icon(
                    library.isLiked(track)
                        ? Icons.favorite
                        : Icons.favorite_border,
                    color: library.isLiked(track)
                        ? TunoraColors.green
                        : TunoraColors.textSecondary,
                  ),
                  onPressed: () => library.toggleLike(track),
                ),
                DownloadButton(track: track),
              ],
            ),
            onTap: () => playList(tracks, index),
          ),
        );
      },
    );
  }
}

class DownloadButton extends StatelessWidget {
  final Track track;
  final double size;
  const DownloadButton({super.key, required this.track, this.size = 24});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: library,
      builder: (context, _) {
        if (library.isDownloaded(track)) {
          return IconButton(
            iconSize: size,
            icon: const Icon(Icons.arrow_circle_down,
                color: TunoraColors.green),
            tooltip: 'Remove download',
            onPressed: () => library.removeDownload(track),
          );
        }
        if (library.isDownloading(track)) {
          return SizedBox(
            width: 48,
            height: 48,
            child: Center(
              child: SizedBox(
                width: size - 6,
                height: size - 6,
                child: CircularProgressIndicator(
                  value: library.progress[track.key],
                  strokeWidth: 2.5,
                  color: TunoraColors.green,
                ),
              ),
            ),
          );
        }
        if (!track.canDownload) {
          return IconButton(
            iconSize: size,
            icon: const Icon(Icons.download_for_offline_outlined,
                color: Color(0xFF535353)),
            tooltip: 'Download not available for this song',
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                  content:
                      Text('The artist has not allowed downloads for this song.')),
            ),
          );
        }
        return IconButton(
          iconSize: size,
          icon: const Icon(Icons.arrow_circle_down_outlined,
              color: TunoraColors.textSecondary),
          tooltip: 'Download',
          onPressed: () => library.download(track),
        );
      },
    );
  }
}
