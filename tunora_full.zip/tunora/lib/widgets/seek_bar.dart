import 'package:flutter/material.dart';
import '../theme.dart';

class SeekBar extends StatefulWidget {
  final Duration duration;
  final Duration position;
  final ValueChanged<Duration> onSeek;
  const SeekBar({
    super.key,
    required this.duration,
    required this.position,
    required this.onSeek,
  });

  @override
  State<SeekBar> createState() => _SeekBarState();
}

class _SeekBarState extends State<SeekBar> {
  double? _drag;

  String _fmt(Duration d) {
    final m = d.inMinutes;
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final max = widget.duration.inMilliseconds.toDouble().clamp(1.0, double.infinity).toDouble();
    final value =
        (_drag ?? widget.position.inMilliseconds.toDouble()).clamp(0.0, max).toDouble();
    return Column(
      children: [
        Slider(
          min: 0,
          max: max,
          value: value,
          onChanged: (v) => setState(() => _drag = v),
          onChangeEnd: (v) {
            widget.onSeek(Duration(milliseconds: v.round()));
            setState(() => _drag = null);
          },
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 22),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(_fmt(Duration(milliseconds: value.round())),
                  style: const TextStyle(
                      color: TunoraColors.textSecondary, fontSize: 12)),
              Text(_fmt(widget.duration),
                  style: const TextStyle(
                      color: TunoraColors.textSecondary, fontSize: 12)),
            ],
          ),
        ),
      ],
    );
  }
}
