import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../theme.dart';

/// Little bouncing bars shown next to the song that is playing.
class NowPlayingBars extends StatefulWidget {
  final bool animate;
  const NowPlayingBars({super.key, this.animate = true});

  @override
  State<NowPlayingBars> createState() => _NowPlayingBarsState();
}

class _NowPlayingBarsState extends State<NowPlayingBars>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  );

  @override
  void initState() {
    super.initState();
    if (widget.animate) _c.repeat();
  }

  @override
  void didUpdateWidget(covariant NowPlayingBars old) {
    super.didUpdateWidget(old);
    if (widget.animate && !_c.isAnimating) _c.repeat();
    if (!widget.animate && _c.isAnimating) _c.stop();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 18,
      height: 16,
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, __) => Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: List.generate(3, (i) {
            final t = _c.value * 2 * math.pi + i * 1.7;
            final h = 4 + 12 * (0.5 + 0.5 * math.sin(t));
            return Container(
              width: 4,
              height: widget.animate ? h : 8,
              color: TunoraColors.green,
            );
          }),
        ),
      ),
    );
  }
}
