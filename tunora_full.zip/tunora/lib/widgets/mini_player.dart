import 'package:audio_service/audio_service.dart';
import 'package:flutter/material.dart';
import '../app_state.dart';
import '../screens/player_screen.dart';
import '../theme.dart';
import 'track_tile.dart';

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<MediaItem?>(
      stream: audioHandler.mediaItem,
      builder: (context, snap) {
        final item = snap.data;
        if (item == null) return const SizedBox.shrink();
        return GestureDetector(
          onTap: () => openPlayer(context),
          child: Container(
            margin: const EdgeInsets.fromLTRB(8, 0, 8, 6),
            decoration: BoxDecoration(
              color: const Color(0xFF3A2E2E),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Row(
                    children: [
                      TrackArt(url: item.artUri?.toString(), size: 40),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(item.title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w600, fontSize: 14)),
                            Text(item.artist ?? '',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    color: TunoraColors.textSecondary,
                                    fontSize: 12)),
                          ],
                        ),
                      ),
                      StreamBuilder<PlaybackState>(
                        stream: audioHandler.playbackState,
                        builder: (_, s) {
                          final playing = s.data?.playing ?? false;
                          return IconButton(
                            icon: Icon(
                                playing ? Icons.pause : Icons.play_arrow,
                                size: 30),
                            onPressed:
                                playing ? audioHandler.pause : audioHandler.play,
                          );
                        },
                      ),
                    ],
                  ),
                ),
                StreamBuilder<Duration>(
                  stream: AudioService.position,
                  builder: (_, s) {
                    final total = item.duration?.inMilliseconds ?? 0;
                    final pos = s.data?.inMilliseconds ?? 0;
                    return Padding(
                      padding: const EdgeInsets.fromLTRB(8, 0, 8, 4),
                      child: LinearProgressIndicator(
                        value: total > 0 ? (pos / total).clamp(0.0, 1.0) : 0,
                        minHeight: 2,
                        backgroundColor: Colors.white24,
                        color: Colors.white,
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
