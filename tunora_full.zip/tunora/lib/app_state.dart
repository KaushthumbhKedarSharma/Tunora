import 'models/track.dart';
import 'services/audio_handler.dart';
import 'services/backend_service.dart';
import 'services/catalog_service.dart';
import 'services/library_store.dart';

/// Simple app-wide singletons.
late TunoraAudioHandler audioHandler;
final BackendService backend = BackendService();
final CatalogService catalog = CatalogService(backend);
final LibraryStore library = LibraryStore();

Future<void> playList(List<Track> tracks, int index) =>
    audioHandler.playTracks(tracks, index, library.localPath);
