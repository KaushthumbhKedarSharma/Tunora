import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/track.dart';

class AudiusService {
  static const _app = 'Tunora';
  static String _host = 'https://discoveryprovider.audius.co';
  static bool _resolved = false;

  /// Finds a working Audius server. Call once at app start.
  static Future<void> warmUp() async {
    if (_resolved) return;
    try {
      final r = await http
          .get(Uri.parse('https://api.audius.co'))
          .timeout(const Duration(seconds: 5));
      final hosts = (jsonDecode(r.body)['data'] as List).cast<String>();
      if (hosts.isNotEmpty) {
        _host = hosts.first;
        _resolved = true;
      }
    } catch (_) {}
  }

  static String streamUrl(String id) =>
      '$_host/v1/tracks/$id/stream?app_name=$_app';

  Future<List<Track>> trending({int limit = 20, String? time}) =>
      _fetch('/v1/tracks/trending', {
        'limit': '$limit',
        if (time != null) 'time': time,
      });

  Future<List<Track>> search(String query, {int limit = 20}) =>
      _fetch('/v1/tracks/search', {'query': query, 'limit': '$limit'});

  Future<List<Track>> _fetch(String path, Map<String, String> params) async {
    try {
      await warmUp();
      final uri = Uri.parse('$_host$path')
          .replace(queryParameters: {...params, 'app_name': _app});
      final r = await http.get(uri).timeout(const Duration(seconds: 12));
      if (r.statusCode != 200) return [];
      final data = jsonDecode(r.body)['data'] as List;
      return data
          .map((e) => _parse(e as Map<String, dynamic>))
          .whereType<Track>()
          .toList();
    } catch (_) {
      return [];
    }
  }

  Track? _parse(Map<String, dynamic> j) {
    if (j['is_streamable'] == false) return null;
    final id = j['id']?.toString();
    if (id == null) return null;
    final art = j['artwork'] as Map<String, dynamic>?;
    final stream = streamUrl(id);
    return Track(
      id: id,
      source: TrackSource.audius,
      title: (j['title'] as String?) ?? 'Unknown title',
      artist: ((j['user'] as Map?)?['name'] as String?) ?? 'Unknown artist',
      artUrl: (art?['480x480'] ?? art?['150x150']) as String?,
      streamUrl: stream,
      duration: j['duration'] is num
          ? Duration(seconds: (j['duration'] as num).toInt())
          : null,
      // Only offer download when the artist enabled it on Audius.
      downloadUrl: j['is_downloadable'] == true ? stream : null,
    );
  }
}
