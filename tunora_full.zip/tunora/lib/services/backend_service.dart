import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../config.dart';
import '../models/auto_playlist.dart';
import '../models/track.dart';
import 'audius_service.dart';

/// Talks to Supabase: synced catalog, listening history, auto playlists.
/// If Supabase is not configured, everything returns empty and the app
/// falls back to live Audius/Jamendo.
class BackendService {
  bool ready = false;
  SupabaseClient get _db => Supabase.instance.client;

  Future<void> init() async {
    if (!Config.backendEnabled) return;
    try {
      await Supabase.initialize(
        url: Config.supabaseUrl,
        anonKey: Config.supabaseAnonKey,
      );
      if (_db.auth.currentSession == null) {
        await _db.auth.signInAnonymously();
      }
      ready = true;
    } catch (e) {
      debugPrint('Backend unavailable: $e');
    }
  }

  // ---------- Catalog ----------
  Future<List<Track>> trending({int limit = 30}) =>
      _rows(() => _db.rpc('trending_tracks', params: {'lim': limit}));

  Future<List<Track>> newReleases({int limit = 30}) =>
      _rows(() => _db.rpc('new_releases', params: {'lim': limit}));

  // ---------- Listening history ----------
  Future<void> logPlay(Track t) async {
    if (!ready) return;
    try {
      await _db.from('plays').insert({'track_key': t.key});
    } catch (e) {
      debugPrint('logPlay failed: $e');
    }
  }

  Future<void> setLiked(Track t, bool liked) async {
    if (!ready) return;
    try {
      if (liked) {
        await _db.from('likes').upsert(
          {'track_key': t.key},
          onConflict: 'user_id,track_key',
          ignoreDuplicates: true,
        );
      } else {
        await _db.from('likes').delete().eq('track_key', t.key);
      }
    } catch (e) {
      debugPrint('setLiked failed: $e');
    }
  }

  Future<void> syncLikes(List<Track> liked) async {
    if (!ready || liked.isEmpty) return;
    try {
      await _db.from('likes').upsert(
            liked.map((t) => {'track_key': t.key}).toList(),
            onConflict: 'user_id,track_key',
            ignoreDuplicates: true,
          );
    } catch (e) {
      debugPrint('syncLikes failed: $e');
    }
  }

  // ---------- Auto playlists ----------
  Future<List<AutoPlaylist>> homePlaylists() async {
    if (!ready) return [];
    final out = <AutoPlaylist>[];
    try {
      final now = DateTime.now();
      final day = _dayId(now);
      final week = 'w${_dayId(now.subtract(Duration(days: now.weekday - 1)))}';
      await _pruneCache(day, week);

      // Daily Mix 1-3 (refreshed once a day)
      final genres = await _topGenres(3);
      for (var i = 0; i < genres.length; i++) {
        final n = i + 1;
        final tracks = await _cached(
          'mix${n}_$day',
          () => _rows(() => _db.rpc('daily_mix', params: {'mix_no': n, 'lim': 30})),
        );
        if (tracks.isEmpty) continue;
        out.add(AutoPlaylist(
          id: 'mix$n',
          title: 'Daily Mix $n',
          subtitle: _mixSubtitle(genres[i], tracks),
          tracks: tracks,
        ));
      }

      // Discover Weekly (refreshed every Monday)
      final discover = await _cached(
        'discover_$week',
        () => _rows(() => _db.rpc('discover_weekly', params: {'lim': 30})),
      );
      if (discover.isNotEmpty) {
        out.add(AutoPlaylist(
          id: 'discover',
          title: 'Discover Weekly',
          subtitle: 'New songs picked for you, refreshed every Monday',
          tracks: discover,
        ));
      }

      // Repeat Rewind (always live)
      final rewind =
          await _rows(() => _db.rpc('repeat_rewind', params: {'lim': 30}));
      if (rewind.isNotEmpty) {
        out.add(AutoPlaylist(
          id: 'rewind',
          title: 'Repeat Rewind',
          subtitle: 'Your most played songs this month',
          tracks: rewind,
        ));
      }
    } catch (e) {
      debugPrint('homePlaylists failed: $e');
    }
    return out;
  }

  Future<List<String>> _topGenres(int n) async {
    final data = await _db.rpc('top_genres', params: {'n': n});
    return (data as List).map((e) => e['genre_name'] as String).toList();
  }

  String _mixSubtitle(String genre, List<Track> tracks) {
    final artists = <String>[];
    for (final t in tracks) {
      if (!artists.contains(t.artist)) artists.add(t.artist);
      if (artists.length == 3) break;
    }
    return '$genre with ${artists.join(', ')} and more';
  }

  // ---------- Helpers ----------
  Future<List<Track>> _rows(Future<dynamic> Function() query) async {
    try {
      final data = await query();
      return (data as List)
          .map((e) => trackFromRow(e as Map<String, dynamic>))
          .whereType<Track>()
          .toList();
    } catch (e) {
      debugPrint('Backend query failed: $e');
      return [];
    }
  }

  String _dayId(DateTime d) =>
      '${d.year}${d.month.toString().padLeft(2, '0')}${d.day.toString().padLeft(2, '0')}';

  Future<List<Track>> _cached(
      String key, Future<List<Track>> Function() fetch) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('cache_$key');
    if (raw != null) {
      try {
        return (jsonDecode(raw) as List)
            .map((e) => Track.fromJson(e as Map<String, dynamic>))
            .toList();
      } catch (_) {}
    }
    final fresh = await fetch();
    if (fresh.isNotEmpty) {
      await p.setString(
          'cache_$key', jsonEncode(fresh.map((t) => t.toJson()).toList()));
    }
    return fresh;
  }

  Future<void> _pruneCache(String day, String week) async {
    final p = await SharedPreferences.getInstance();
    for (final k in p.getKeys()) {
      if (k.startsWith('cache_') &&
          !k.endsWith('_$day') &&
          !k.endsWith('_$week')) {
        await p.remove(k);
      }
    }
  }
}

/// Turns a `tracks` table row into a playable Track.
Track? trackFromRow(Map<String, dynamic> r) {
  final source = TrackSource.values.byName(r['source'] as String);
  final id = r['source_id'] as String;
  final isAudius = source == TrackSource.audius;
  final stream =
      isAudius ? AudiusService.streamUrl(id) : (r['stream_url'] as String? ?? '');
  if (stream.isEmpty) return null;
  final downloadable = r['downloadable'] == true;
  return Track(
    id: id,
    source: source,
    title: r['title'] as String,
    artist: r['artist'] as String,
    album: (r['album'] as String?) ?? '',
    artUrl: r['art_url'] as String?,
    streamUrl: stream,
    duration: r['duration_sec'] is num
        ? Duration(seconds: (r['duration_sec'] as num).toInt())
        : null,
    downloadUrl: downloadable
        ? (isAudius ? stream : r['download_url'] as String?)
        : null,
  );
}
