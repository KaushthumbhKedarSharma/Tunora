import 'package:audio_service/audio_service.dart';
import 'package:audio_session/audio_session.dart';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/track.dart';

/// Plays music in the background with notification + lock-screen controls,
/// and exposes the Android equalizer.
class TunoraAudioHandler extends BaseAudioHandler with SeekHandler {
  final AndroidEqualizer equalizer = AndroidEqualizer();
  final AndroidLoudnessEnhancer loudness = AndroidLoudnessEnhancer();
  late final AudioPlayer player;

  final Map<String, Track> _tracks = {};
  bool _eqRestored = false;

  /// Called once per song after 20 seconds of listening.
  void Function(Track)? onPlayCounted;
  String? _countedKey;

  TunoraAudioHandler() {
    player = AudioPlayer(
      audioPipeline: AudioPipeline(androidAudioEffects: [loudness, equalizer]),
    );
    _init();
  }

  Track? trackFor(String key) => _tracks[key];

  Future<void> _init() async {
    final session = await AudioSession.instance;
    await session.configure(const AudioSessionConfiguration.music());
    player.playbackEventStream.listen(_broadcast, onError: (_) {});
    player.currentIndexStream.listen((i) {
      _countedKey = null;
      if (i != null && i >= 0 && i < queue.value.length) {
        mediaItem.add(queue.value[i]);
      }
    });
    player.positionStream.listen((pos) {
      final item = mediaItem.value;
      if (item == null || _countedKey == item.id) return;
      if (player.playing && pos.inSeconds >= 20) {
        _countedKey = item.id;
        final t = _tracks[item.id];
        if (t != null) onPlayCounted?.call(t);
      }
    });
    player.processingStateStream.listen((s) {
      if (s == ProcessingState.completed) {
        // End of queue reached: stay paused at the start.
        player.pause();
        player.seek(Duration.zero, index: 0);
      }
    });
  }

  Future<void> playTracks(
    List<Track> tracks,
    int index,
    String? Function(Track) localPath,
  ) async {
    if (tracks.isEmpty) return;
    final items =
        tracks.map((t) => t.toMediaItem(localPath: localPath(t))).toList();
    for (final t in tracks) {
      _tracks[t.key] = t;
    }
    queue.add(items);
    _countedKey = null;
    final playlist = ConcatenatingAudioSource(
      children: items.map(_toSource).toList(),
    );
    try {
      await player.setAudioSource(playlist,
          initialIndex: index, initialPosition: Duration.zero);
      mediaItem.add(items[index]);
      _restoreEffects();
      player.play();
    } catch (e) {
      debugPrint('Could not start playback: $e');
    }
  }

  AudioSource _toSource(MediaItem m) {
    final url = m.extras!['url'] as String;
    final isLocal = m.extras!['local'] == true;
    return AudioSource.uri(isLocal ? Uri.file(url) : Uri.parse(url), tag: m);
  }

  /// Re-applies the saved equalizer / volume boost once audio is loaded.
  Future<void> _restoreEffects() async {
    if (_eqRestored) return;
    _eqRestored = true;
    try {
      final p = await SharedPreferences.getInstance();
      await equalizer.setEnabled(p.getBool('eq_enabled') ?? false);
      final params = await equalizer.parameters;
      final saved = p.getStringList('eq_gains');
      if (saved != null && saved.length == params.bands.length) {
        for (var i = 0; i < saved.length; i++) {
          await params.bands[i].setGain(double.parse(saved[i]));
        }
      }
      final boost = p.getDouble('eq_boost') ?? 0;
      await loudness.setTargetGain(boost);
      await loudness.setEnabled(boost > 0);
    } catch (e) {
      debugPrint('Could not restore equalizer: $e');
    }
  }

  void _broadcast(PlaybackEvent event) {
    playbackState.add(playbackState.value.copyWith(
      controls: [
        MediaControl.skipToPrevious,
        if (player.playing) MediaControl.pause else MediaControl.play,
        MediaControl.skipToNext,
      ],
      systemActions: const {MediaAction.seek},
      androidCompactActionIndices: const [0, 1, 2],
      processingState: const {
        ProcessingState.idle: AudioProcessingState.idle,
        ProcessingState.loading: AudioProcessingState.loading,
        ProcessingState.buffering: AudioProcessingState.buffering,
        ProcessingState.ready: AudioProcessingState.ready,
        ProcessingState.completed: AudioProcessingState.completed,
      }[player.processingState]!,
      playing: player.playing,
      updatePosition: player.position,
      bufferedPosition: player.bufferedPosition,
      speed: player.speed,
      queueIndex: event.currentIndex,
      shuffleMode: player.shuffleModeEnabled
          ? AudioServiceShuffleMode.all
          : AudioServiceShuffleMode.none,
      repeatMode: const {
        LoopMode.off: AudioServiceRepeatMode.none,
        LoopMode.one: AudioServiceRepeatMode.one,
        LoopMode.all: AudioServiceRepeatMode.all,
      }[player.loopMode]!,
    ));
  }

  @override
  Future<void> play() => player.play();

  @override
  Future<void> pause() => player.pause();

  @override
  Future<void> seek(Duration position) => player.seek(position);

  @override
  Future<void> skipToNext() => player.seekToNext();

  @override
  Future<void> skipToPrevious() => player.seekToPrevious();

  @override
  Future<void> skipToQueueItem(int index) =>
      player.seek(Duration.zero, index: index);

  @override
  Future<void> stop() async {
    await player.stop();
    return super.stop();
  }

  @override
  Future<void> setShuffleMode(AudioServiceShuffleMode shuffleMode) async {
    final on = shuffleMode == AudioServiceShuffleMode.all;
    if (on) await player.shuffle();
    await player.setShuffleModeEnabled(on);
    _broadcast(player.playbackEvent);
  }

  @override
  Future<void> setRepeatMode(AudioServiceRepeatMode repeatMode) async {
    await player.setLoopMode(const {
      AudioServiceRepeatMode.none: LoopMode.off,
      AudioServiceRepeatMode.one: LoopMode.one,
      AudioServiceRepeatMode.all: LoopMode.all,
      AudioServiceRepeatMode.group: LoopMode.all,
    }[repeatMode]!);
    _broadcast(player.playbackEvent);
  }
}
