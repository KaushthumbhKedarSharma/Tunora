import '../models/track.dart';
import 'audius_service.dart';
import 'backend_service.dart';
import 'jamendo_service.dart';

/// Home sections come from the synced Supabase catalog when available,
/// otherwise live from Audius + Jamendo. Search is always live.
class CatalogService {
  final BackendService _backend;
  final _audius = AudiusService();
  final _jamendo = JamendoService();

  CatalogService(this._backend);

  bool get jamendoEnabled => _jamendo.enabled;

  Future<List<Track>> trending() async {
    if (_backend.ready) {
      final t = await _backend.trending();
      if (t.isNotEmpty) return t;
    }
    final r = await Future.wait([_audius.trending(), _jamendo.popular()]);
    return _merge(r);
  }

  Future<List<Track>> freshReleases() async {
    if (_backend.ready) {
      final t = await _backend.newReleases();
      if (t.isNotEmpty) return t;
    }
    if (_jamendo.enabled) return _jamendo.newReleases();
    return _audius.trending(time: 'week');
  }

  Future<List<Track>> search(String query) async {
    final r = await Future.wait([_audius.search(query), _jamendo.search(query)]);
    return _merge(r);
  }

  /// Interleaves sources and removes duplicates (same title + artist).
  List<Track> _merge(List<List<Track>> lists) {
    final out = <Track>[];
    final seen = <String>{};
    final longest =
        lists.map((l) => l.length).fold<int>(0, (a, b) => a > b ? a : b);
    for (var i = 0; i < longest; i++) {
      for (final l in lists) {
        if (i >= l.length) continue;
        final t = l[i];
        final sig = '${t.title.toLowerCase()}|${t.artist.toLowerCase()}';
        if (seen.add(sig)) out.add(t);
      }
    }
    return out;
  }
}
