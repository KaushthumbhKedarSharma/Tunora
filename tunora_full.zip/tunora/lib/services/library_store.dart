import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/track.dart';

/// Liked songs + offline downloads, saved on the device.
class LibraryStore extends ChangeNotifier {
  late SharedPreferences _p;
  final List<Track> liked = [];
  final Map<String, Track> _dlTracks = {};
  final Map<String, String> _dlPaths = {};
  final Map<String, double> progress = {};

  /// Lets the backend know when a song is liked/unliked.
  void Function(Track, bool)? onLikeChanged;

  Future<void> init() async {
    _p = await SharedPreferences.getInstance();
    for (final s in _p.getStringList('liked') ?? <String>[]) {
      liked.add(Track.fromJson(jsonDecode(s) as Map<String, dynamic>));
    }
    for (final s in _p.getStringList('downloads') ?? <String>[]) {
      final m = jsonDecode(s) as Map<String, dynamic>;
      final t = Track.fromJson(m['track'] as Map<String, dynamic>);
      final path = m['path'] as String;
      if (File(path).existsSync()) {
        _dlTracks[t.key] = t;
        _dlPaths[t.key] = path;
      }
    }
  }

  bool isLiked(Track t) => liked.any((e) => e.key == t.key);

  void toggleLike(Track t) {
    if (isLiked(t)) {
      liked.removeWhere((e) => e.key == t.key);
    } else {
      liked.insert(0, t);
    }
    _p.setStringList('liked', liked.map((e) => jsonEncode(e.toJson())).toList());
    notifyListeners();
    onLikeChanged?.call(t, isLiked(t));
  }

  List<Track> get downloads => _dlTracks.values.toList();
  String? localPath(Track t) => _dlPaths[t.key];
  bool isDownloaded(Track t) => _dlPaths.containsKey(t.key);
  bool isDownloading(Track t) => progress.containsKey(t.key);

  Future<void> download(Track t) async {
    if (!t.canDownload || isDownloaded(t) || isDownloading(t)) return;
    final dir = await getApplicationDocumentsDirectory();
    final folder = Directory('${dir.path}/downloads');
    if (!folder.existsSync()) folder.createSync(recursive: true);
    final path = '${folder.path}/${t.key}.mp3';
    progress[t.key] = 0;
    notifyListeners();
    try {
      await Dio().download(
        t.downloadUrl!,
        path,
        onReceiveProgress: (received, total) {
          if (total > 0) {
            progress[t.key] = received / total;
            notifyListeners();
          }
        },
      );
      _dlTracks[t.key] = t;
      _dlPaths[t.key] = path;
      _saveDownloads();
    } catch (_) {
      final f = File(path);
      if (f.existsSync()) f.deleteSync();
    } finally {
      progress.remove(t.key);
      notifyListeners();
    }
  }

  Future<void> removeDownload(Track t) async {
    final path = _dlPaths.remove(t.key);
    _dlTracks.remove(t.key);
    if (path != null && File(path).existsSync()) File(path).deleteSync();
    _saveDownloads();
    notifyListeners();
  }

  void _saveDownloads() {
    _p.setStringList(
      'downloads',
      _dlTracks.values
          .map((t) => jsonEncode({'track': t.toJson(), 'path': _dlPaths[t.key]}))
          .toList(),
    );
  }
}
