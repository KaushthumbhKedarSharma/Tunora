import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/track.dart';

/// Get a free client id at https://developer.jamendo.com and run with:
/// flutter run --dart-define=JAMENDO_CLIENT_ID=your_id
class JamendoService {
  static const clientId =
      String.fromEnvironment('JAMENDO_CLIENT_ID', defaultValue: '');
  bool get enabled => clientId.isNotEmpty;

  Future<List<Track>> popular({int limit = 20}) =>
      _fetch({'order': 'popularity_week', 'limit': '$limit'});

  Future<List<Track>> newReleases({int limit = 20}) =>
      _fetch({'order': 'releasedate_desc', 'limit': '$limit'});

  Future<List<Track>> search(String query, {int limit = 20}) =>
      _fetch({'search': query, 'limit': '$limit'});

  Future<List<Track>> _fetch(Map<String, String> params) async {
    if (!enabled) return [];
    try {
      final uri = Uri.https('api.jamendo.com', '/v3.0/tracks/', {
        'client_id': clientId,
        'format': 'json',
        'audioformat': 'mp32',
        'audiodlformat': 'mp32',
        'imagesize': '500',
        ...params,
      });
      final r = await http.get(uri).timeout(const Duration(seconds: 12));
      if (r.statusCode != 200) return [];
      final results = jsonDecode(r.body)['results'] as List;
      return results
          .map((e) => _parse(e as Map<String, dynamic>))
          .whereType<Track>()
          .toList();
    } catch (_) {
      return [];
    }
  }

  Track? _parse(Map<String, dynamic> j) {
    final id = j['id']?.toString();
    final audio = j['audio'] as String?;
    if (id == null || audio == null || audio.isEmpty) return null;
    final allowed = j['audiodownload_allowed'] == true;
    final dl = j['audiodownload'] as String?;
    return Track(
      id: id,
      source: TrackSource.jamendo,
      title: (j['name'] as String?) ?? 'Unknown title',
      artist: (j['artist_name'] as String?) ?? 'Unknown artist',
      album: (j['album_name'] as String?) ?? '',
      artUrl: j['image'] as String?,
      streamUrl: audio,
      duration: j['duration'] is num
          ? Duration(seconds: (j['duration'] as num).toInt())
          : null,
      downloadUrl: (allowed && dl != null && dl.isNotEmpty) ? dl : null,
    );
  }
}
