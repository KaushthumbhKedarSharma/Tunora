import 'package:flutter/material.dart';

class TunoraColors {
  static const background = Color(0xFF121212);
  static const surface = Color(0xFF1A1A1A);
  static const card = Color(0xFF2A2A2A);
  static const green = Color(0xFF1ED760);
  static const textPrimary = Colors.white;
  static const textSecondary = Color(0xFFB3B3B3);
}

ThemeData buildTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: TunoraColors.background,
    colorScheme: const ColorScheme.dark(
      primary: TunoraColors.green,
      surface: TunoraColors.background,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: TunoraColors.background,
      elevation: 0,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: const Color(0xF2121212),
      indicatorColor: Colors.transparent,
      height: 62,
      labelTextStyle: WidgetStateProperty.resolveWith((s) => TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w600,
            color: s.contains(WidgetState.selected)
                ? Colors.white
                : TunoraColors.textSecondary,
          )),
      iconTheme: WidgetStateProperty.resolveWith((s) => IconThemeData(
            color: s.contains(WidgetState.selected)
                ? Colors.white
                : TunoraColors.textSecondary,
          )),
    ),
    sliderTheme: const SliderThemeData(
      activeTrackColor: Colors.white,
      inactiveTrackColor: Color(0x55FFFFFF),
      thumbColor: Colors.white,
      trackHeight: 4,
      thumbShape: RoundSliderThumbShape(enabledThumbRadius: 6),
      overlayShape: RoundSliderOverlayShape(overlayRadius: 14),
    ),
  );
}
